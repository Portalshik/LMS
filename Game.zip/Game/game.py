print("Game In Work!")
