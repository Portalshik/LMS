import sqlite3

con = sqlite3.connect(input())
cur = con.cursor()

result1 = cur.execute("""SELECT FILMS.title FROM FILMS
    WHERE duration >= 60 AND genre=(
    SELECT genres.id FROM genres
        WHERE genres.title = 'комедия'
)""").fetchall()

for i in result1:
    print(i[0])
con.close()
