from flask import Flask, url_for, request

app = Flask(__name__)


@app.route('/')
def empty():
    return "Миссия Колонизация Марса"


@app.route('/index')
def index():
    return "И на Марсе будут яблони цвести!"


@app.route("/promotion")
def promotion():
    return """Человечество вырастает из детства.<br>

Человечеству мала одна планета.<br>

Мы сделаем обитаемыми безжизненные пока планеты.<br>

И начнем с Марса!<br>

Присоединяйся!<br>"""


@app.route("/image_mars")
def image_mars():
    return f"""<!DOCTYPE html>
<html lang="ru">
<head>
    <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
    <h2>Жди Нас, Марс!</h2><img src='{url_for('static', filename="img/mars.png")}' alt="Stop, Where Is This Picture?">
<br>
    <div class="alert alert-dark" role="alert">
        Человечество вырастает из детства.
    </div>
    <div class="alert alert-success" role="alert">
        Человечеству мала одна планета.
    </div>
    <div class="alert alert-dark" role="alert">
        Мы сделаем обитаемыми безжизненные пока планетыю.
    </div>
    <div class="alert alert-warning" role="alert">
        И начнём с Марса!
    </div>
    <div class="alert alert-danger" role="alert">
        Присоединяйся!
    </div>
</body>
</html>"""


@app.route('/astronaut_selection', methods=["GET", "POST"])
def astronaut_selection():
    if request.method == "GET":
        return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
    <h1>Анкета претендента на участие в миссии</h1>
    <div>
        <form class="login_form" method="post">
            <input type="text" class="form-control" placeholder="Введите фамилия" name="surname">
            <input type="text" class="form-control" placeholder="Введите имя" name="name">
            <label for="classSelect">Ваше образование</label>
            <div class="form-group">
                <select class="form-control" id="classSelect" name="education">
                    <option>Начальное</option>
                    <option>Основное</option>
                    <option>Среднее</option>
                    <option>Высшее</option>
                </select>
            </div>
            <label for="classSelect">Ваши профессии</label>
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Инженер-исследователь</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Пилот</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Строитель</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Экзобиолог</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Врач</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Инженер по терраформированию</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Климатолог</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Специалист по радиационной защите</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Астрогеолог</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Гляциолог</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Инженер жизнеобеспечения</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Метеоролог</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Оператор марсохода</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Киберинженер</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Штурман</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Пилот дронов</label>
            </div>
            
            <div class="form-group">
                <label for="form-check">Укажите пол</label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="sex" id="male" value="male" checked>
                    <label class="form-check-label" for="male">
                        Мужской
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="sex" id="female" value="female">
                    <label class="form-check-label" for="female">
                        Женский
                    </label>
                </div>
            </div>

            
            <div class="form-group">
                <label for="about">Почему вы хотети принять участие в миссии</label>
                <textarea class="form-control" id="about" rows="3" name="reason"></textarea>
            </div>
            <div class="form-group">
                <label for="photo">Приложите фотографию</label>
                <input type="file" class="form-control-file" id="photo" name="file">
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
                <label class="form-check-label" for="acceptRules">Готовы остаться на Марсе?</label>
            </div>
            <button type="submit" class="btn btn-primary">Записаться</button>
        </form>
    </div>
</body>
</html>"""
    elif request.method == "POST":
        print(f'Surname: {request.form["surname"]}')
        print(f'Name: {request.form["name"]}')
        print(f'Education: {request.form["education"]}')
        print(f'Jobs: {request.form["job"]}')
        print(f'Reason: {request.form["reason"]}')
        print(f'Sex: {request.form["sex"]}')
        print(f'Accept: {request.form["accept"]}')
        return "Form Is Work!"


@app.route("/choice/<planet>")
def choice(planet):
    planet = planet.lower()
    data = ['Земля']
    res = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
    <h1>Моё предложение: {0}</h1>
    <h3>{1}</h3>
    
    <div class="alert alert-success" role="alert">
        {2};
    </div>
    
    <div class="alert alert-secondary" role="alert">
        {3};
    </div>
    
    <div class="alert alert-warning" role="alert">
        {4};
    </div>
    
    <div class="alert alert-danger" role="alert">
        {5}
    </div>
</body>
</html>"""
    if planet == "земля" or planet == "earth":
        return res.format(
            "Земля",
            "",
            "Это единственная известная планета с жизнью",
            "Земля имеет возраст более 4,5 млрд лет",
            "И только здесь есть самый ценный для жизни ресурс",
            "Да и с Космоса Земля самая красивая!"
        )
    elif planet == "венера" or planet == "venus":
        return res.format(
            "Венера",
            "Эта планета близка к Земле;",
            "Самая яркая планета в Солнечной системе",
            "Ее еще называют Утренней звездой",
            "Венеру символично считают сестрой Земли",
            "На Венере нет и не может быть жизни!"
        )
    elif planet == "меркурий" or planet == "mercury":
        return res.format(
            "Меркурий",
            "Эта планета не близко к Земле;",
            "Первая планета, ближайшая к солнцу",
            "Она очень маленькая",
            "Здесь очень жарко днем и нереально холодно с наступлением ночи",
            "А если бы здесь была жизнь, то ее жители могли наблюдать рассвет и закат Солнца до 4 раз в сутки!"
        )
    elif planet == "марс" or planet == "mars":
        return res.format(
            "Марс",
            "Эта планета близка к Земле;",
            "Одна из наиболее изучаемых землянами планет",
            "Планета получила свое название в честь римского бога войн",
            "На планете много вулканов, долин, кратеров и пустынь",
            "А ещё здесь огромные горы, самые большие среди всех планет!"
        )
    elif planet == "юпитер" or planet == "jupiter":
        return res.format(
            "Юпитер",
            "Эта планета не близко к Земле;",
            "Наибольшая планета из всех гигантов",
            "Планета сплошь состоит из газа",
            "Сила тяготения на Юпитере в сотни раз больше, чем сила тяготения на других планетах",
            "А ещё она в триста раз тяжелее нашей планеты и рекордсмен по спутникам – у Юпитера их 69!"
        )
    elif planet == "сатурн" or planet == "saturn":
        return res.format(
            "Сатурн",
            "Интересная особенность Сатурна – его кольца",
            "Кольца представляют собой облака, состоящие из движущихся в одном направлении камней, льда и пыли.",
            "Эта планета также состоит из газа",
            "Она имеет целых 62 спутника",
            "Интересно, что будучи второй по величине планетой-гигантом после Юпитера, Сатурн является еще и самой легкой планетой!"
        )
    elif planet == "уран" or planet == "uranus":
        return res.format(
            "Уран",
            "Планета тоже имеет своеобразные кольца, которые видны в какие-то определенные моменты",
            "Уран относится к планетам-гигантам",
            "Температура на ней около -220 градусов",
            "У Урана ученые насчитали 27 спутников",
            "Интересно, что планета движется, лежа как бы на боку!"
        )
    elif planet == "нептун" or planet == "neptune":
        return res.format(
            "Нептун",
            "Единственная планета, которая была обнаружена с помощью математических вычислений, а не с помощью наблюдения",
            "Если предположить гостевой полет в гости к Нептуну, то понадобится как минимум 12 земных лет",
            "Очень красивая планета голубого цвета",
            "Очень красивая планета голубого цвета",
            "Скорость ветра на планете Нептун может превышать 2000 километров в час!"
        )
    elif planet == "плутон" or planet == "pluto":
        return res.format(
            "Плутон",
            "Стоит упомянуть и маленький Плутон",
            "Некогда считавшаяся планетой, планета Плутон самая миниатюрная",
            "Она в шесть раз меньше луны",
            "Состоит из камня и льда",
            "А ещё самая далекая от Солнца планета!"
        )


if __name__ == '__main__':
    app.run(port=8000, host='127.0.0.1')
