from flask import Flask, url_for, request

app = Flask(__name__)


@app.route('/')
def empty():
    return "Миссия Колонизация Марса"


@app.route('/index')
def index():
    return "И на Марсе будут яблони цвести!"


@app.route("/promotion")
def promotion():
    return """Человечество вырастает из детства.<br>

Человечеству мала одна планета.<br>

Мы сделаем обитаемыми безжизненные пока планеты.<br>

И начнем с Марса!<br>

Присоединяйся!<br>"""


@app.route("/image_mars")
def image_mars():
    return f"""<!DOCTYPE html>
<html lang="ru">
<head>
    <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
    <h2>Жди Нас, Марс!</h2><img src='{url_for('static', filename="img/mars.png")}' alt="Stop, Where Is This Picture?">
<br>
    <div class="alert alert-dark" role="alert">
        Человечество вырастает из детства.
    </div>
    <div class="alert alert-success" role="alert">
        Человечеству мала одна планета.
    </div>
    <div class="alert alert-dark" role="alert">
        Мы сделаем обитаемыми безжизненные пока планетыю.
    </div>
    <div class="alert alert-warning" role="alert">
        И начнём с Марса!
    </div>
    <div class="alert alert-danger" role="alert">
        Присоединяйся!
    </div>
</body>
</html>"""


@app.route('/astronaut_selection', methods=["GET", "POST"])
def astronaut_selection():
    if request.method == "GET":
        return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
    <h1>Анкета претендента на участие в миссии</h1>
    <div>
        <form class="login_form" method="post">
            <input type="text" class="form-control" placeholder="Введите фамилия" name="surname">
            <input type="text" class="form-control" placeholder="Введите имя" name="name">
            <label for="classSelect">Ваше образование</label>
            <div class="form-group">
                <select class="form-control" id="classSelect" name="education">
                    <option>Начальное</option>
                    <option>Основное</option>
                    <option>Среднее</option>
                    <option>Высшее</option>
                </select>
            </div>
            <label for="classSelect">Ваши профессии</label>
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Инженер-исследователь</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Пилот</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Строитель</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Экзобиолог</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Врач</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Инженер по терраформированию</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Климатолог</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Специалист по радиационной защите</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Астрогеолог</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Гляциолог</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Инженер жизнеобеспечения</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Метеоролог</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Оператор марсохода</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Киберинженер</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Штурман</label>
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="job">
                <label class="form-check-label" for="acceptRules">Пилот дронов</label>
            </div>
            
            <div class="form-group">
                <label for="form-check">Укажите пол</label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="sex" id="male" value="male" checked>
                    <label class="form-check-label" for="male">
                        Мужской
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="sex" id="female" value="female">
                    <label class="form-check-label" for="female">
                        Женский
                    </label>
                </div>
            </div>

            
            <div class="form-group">
                <label for="about">Почему вы хотети принять участие в миссии</label>
                <textarea class="form-control" id="about" rows="3" name="reason"></textarea>
            </div>
            <div class="form-group">
                <label for="photo">Приложите фотографию</label>
                <input type="file" class="form-control-file" id="photo" name="file">
            </div>
            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
                <label class="form-check-label" for="acceptRules">Готовы остаться на Марсе?</label>
            </div>
            <button type="submit" class="btn btn-primary">Записаться</button>
        </form>
    </div>
</body>
</html>"""
    elif request.method == "POST":
        print(f'Surname: {request.form["surname"]}')
        print(f'Name: {request.form["name"]}')
        print(f'Education: {request.form["education"]}')
        print(f'Jobs: {request.form["job"]}')
        print(f'Reason: {request.form["reason"]}')
        print(f'Sex: {request.form["sex"]}')
        print(f'Accept: {request.form["accept"]}')
        return "Form Is Work!"


if __name__ == '__main__':
    app.run(port=8000, host='127.0.0.1')
