import pygame

pygame.init()


width = 600
height = 400
size = (width, height)
screen = pygame.display.set_mode(size)


class Arrow:
    def __init__(self):
        self.Cursor = pygame.image.load('data/arrow.png')
        pygame.mouse.set_visible(False)

    def render(self, mouse_pos):
        screen.blit(self.Cursor, (mouse_pos[0], mouse_pos[1]))


Cursor = Arrow()

running = True
flag = False
pos = None
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEMOTION:
            pos = event.pos
            flag = True
    screen.fill((0, 0, 0))
    try:
        Cursor.render(pos)
    except TypeError:
        pass
    pygame.display.flip()
pygame.quit()
