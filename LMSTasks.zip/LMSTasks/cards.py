import pygame

pygame.init()

width = 600
height = 400
size = (width, height)
screen = pygame.display.set_mode(size)
all_sprites = pygame.sprite.Group()
player = pygame.sprite.Sprite()
player.image = pygame.image.load('creature.png')
player.rect = player.image.get_rect()
player.rect.x = size[0] // 2
player.rect.y = size[1] // 2
all_sprites.add(player)


class Arrow:
    def __init__(self):
        self.Cursor = pygame.image.load('data/creature.png')
        pygame.mouse.set_visible(False)

    def render(self, sprite, special=False, coords=(0, 0)):
        if special:
            sprite.rect.x += coords[0]
            sprite.rect.y += coords[1]
        print(sprite.rect.x, sprite.rect.y)
        all_sprites.draw(screen)


Cursor = Arrow()

running = True
flag = False
pos = None
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                Cursor.render(player, special=True, coords=(0, -10))
            if event.key == pygame.K_DOWN:
                Cursor.render(player, special=True, coords=(0, 10))
            if event.key == pygame.K_LEFT:
                Cursor.render(player, special=True, coords=(-10, 0))
            if event.key == pygame.K_RIGHT:
                Cursor.render(player, special=True, coords=(10, 0))
    screen.fill((0, 0, 0))
    Cursor.render(player)
    pygame.display.flip()
pygame.quit()
