import pygame

pygame.init()

width = 600
height = 95
size = (width, height)
screen = pygame.display.set_mode(size)
all_sprites = pygame.sprite.Group()
clock = pygame.time.Clock()


class Car(pygame.sprite.Sprite):
    def __init__(self):
        super(Car, self).__init__()
        self.sprite = pygame.sprite.Sprite()
        self.sprite.image = pygame.image.load("data/car1.png")
        self.sprite.rect = self.sprite.image.get_rect()
        self.sprite.rect.x = 0
        self.sprite.rect.y = 0

    def rotate(self, left=False, right=False):
        if left:
            self.sprite.image = pygame.image.load("data/car2.png")
        if right:
            self.sprite.image = pygame.image.load("data/car1.png")

    def move(self, x):
        self.sprite.rect.x += x


player = Car()
all_sprites.add(player.sprite)
running = True
flag = False
pos = None
moving = 1
while running:
    screen.fill((255, 255, 255))
    all_sprites.draw(screen)
    player.move(moving)
    if player.sprite.rect.x + 150 >= width:
        moving = -1
        player.rotate(left=True)
    if player.sprite.rect.x <= 0:
        moving = 1
        player.rotate(right=True)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    pygame.display.flip()
    clock.tick(90)
pygame.quit()
