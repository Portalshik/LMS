import pygame

size = width, height = 600, 300
screen = pygame.display.set_mode(size)
fps = 100
clock = pygame.time.Clock()

running = True
sprites = pygame.sprite.Group()
gameover = pygame.sprite.Sprite()
gameover.image = pygame.image.load('data/gameover.png')
gameover.rect = gameover.image.get_rect()
gameover.rect.x = -width
gameover.rect.y = 0
sprites.add(gameover)
screen.fill((0, 0, 255))
while running:
    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            running = False
    sprites.draw(screen)
    if gameover.rect.x + width <= width:
        gameover.rect.x += 1
    pygame.display.flip()
    clock.tick(fps)

pygame.quit()
